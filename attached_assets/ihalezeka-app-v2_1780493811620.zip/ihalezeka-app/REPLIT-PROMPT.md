# İhaleZeka — Replit Agent Prompt'u

> Bu metni Replit Agent'a olduğu gibi yapıştır. Mockup HTML dosyalarını da projeye yükle ki Agent tasarımı referans alsın.

---

## PROJE BRIEFİ

Build a production-grade SaaS web application called **İhaleZeka** — an AI-powered Turkish public procurement (kamu ihale) intelligence platform. It is the Turkish-market adaptation of cleat.ai (CLEATUS), which serves the US government-contracting market. Our market is the Turkish EKAP system (Elektronik Kamu Alımları Platformu) and tenders governed by Law No. 4734 (Kamu İhale Kanunu).

The entire UI must be in **Turkish**. I am attaching HTML mockups of every screen — match their layout, structure, and component design closely. They are the source of truth for look & feel.

## TECH STACK (kullan)
- **Frontend:** Next.js 14 (App Router) + TypeScript + Tailwind CSS
- **UI:** shadcn/ui components, Tabler Icons (`@tabler/icons-react`), Sora (headings) + Inter (body) fonts
- **State/Data:** TanStack Query for server state; Zustand for light client state
- **Backend:** Next.js API routes (or a separate Express service if cleaner)
- **Database:** PostgreSQL via Prisma ORM (Replit DB or Neon)
- **Auth:** Clerk (multi-tenant: organization → business → users, like CLEATUS)
- **AI layer:** Provider-agnostic — user supplies their OWN API key (OpenAI / Anthropic / Gemini). Store keys encrypted (AES-256), never log them.
- **Payments:** Stripe (subscription tiers: Trial / Essential / Pro / Enterprise + per-seat)

## DESIGN SYSTEM (mockup'lardaki gibi)
- Light + dark theme with a toggle in the top bar; persist choice. Use CSS variables exactly like the attached `theme.css` (brand navy-blue `#2C46D8`, green/amber/red semantic colors).
- Shared shell: collapsible left sidebar (nav defined in one place) + sticky top bar (search + "AI Asistan" button + theme toggle + notifications + avatar).
- Cards with subtle shadows, rounded corners (radius 14-18px), generous spacing. Minimal, professional, NOT flashy.
- Agency logo component: when a real logo URL exists, show it; otherwise render a colored initials badge (hash agency name → consistent color). See `izAgencyLogo` in the mockup `app.js`.

## PAGES TO BUILD (her biri mockup'ta var)
1. **landing.html** → Public marketing page (hero, features, data-source logos, stats band, how-it-works, CTA).
2. **Dashboard** → 6 KPI stat cards, "en uygun ihaleler" list (with agency logos + fit score), money-flow sparkline, AI assistant quick-actions, pipeline summary, AI win-prediction bars.
3. **Fırsatlarım (Opportunities)** → Filterable table of matched tenders: fit-score badge (green/amber/red), agency logo, İKN, estimated value, deadline countdown, pagination.
4. **İhale Detayı (Tender detail)** → AI summary, circular fit-score gauge, qualification-criteria compliance checklist (uygun/eksik), pros & risks, "Benim adıma başvur" + "Teklif taslağı oluştur" CTAs, document list.
5. **Benim Adıma Başvur (Apply-on-my-behalf wizard)** → 6-step company-profile setup: (1) firma kimliği [vergi no, MERSİS, EKAP], (2) faaliyet alanları [NACE/CPV], (3) mali yeterlilik [ciro, bilanço, banka], (4) iş deneyimi & personel, (5) teklif stratejisi [bütçe, tercih edilen/çalışılmayacak iller, kırım oranı], (6) otomasyon yetkisi [onay limiti, bildirim kanalları]. Progress bar + step sidebar.
6. **Teklif Oluşturucu (Proposal generator)** → Split view: left = AI chat panel, right = live editable proposal document preview. Export to PDF/Word.
7. **İhale Arama (Search)** → Natural-language search bar + faceted filters (il, tür, bedel, son tarih, idare, CPV, usul) + result cards with agency logos.
8. **Boru Hattı (Pipeline)** → Kanban board: Fırsat Keşfi → Teklif Hazırlığı → Başvuru Yapıldı → Değerlendirme → Kazanıldı. Drag-and-drop cards.
9. **Rakip Analizi (Competitor analysis)** → Competitor table (kazanılan ihale, kırım oranı, sizinle karşılaşma), AI insight, category win-rate bars.
10. **Para Akışı (Money flow)** → Agency-spending analytics: monthly trend chart, category donut, top-spending agencies table with logos.
11. **Belgelerim (Document hub)** → Folders, document table with validity tracking (geçerli/yaklaşıyor/süresi dolmuş), upload.
12. **Raporlar (Reports)** → Performance KPIs, monthly applications-vs-wins bar chart, category-performance bars, AI executive summary.
13. **Entegrasyonlar & API (Integrations)** → User connects their OWN AI provider keys (OpenAI/Claude/Gemini, bring-your-own-key, stored encrypted), data-source toggles (EKAP active; belediye & uluslararası gated by plan), İhaleZeka REST API keys, webhook/Zapier.

## GLOBAL: Kayan AI Asistan Paneli
A right-side sliding panel ("İhaleZeka'ya Sor", BETA badge) available on every page via the top-bar "AI Asistan" button — mirrors CLEATUS's "Ask CLEATUS". It shows scored recommendations (e.g. 98/100), agency logos, CPV codes, status badges (PİPELINE'DA / YENİ / İZLENİYOR), and action buttons (Pipeline'a ekle / Aç / Çıkar). Powered by the user's connected AI key. Streaming responses.

## DATA MODEL (Prisma) — başlangıç
- `Organization` (multi-tenant root) → `Business` (1-n) → `User` (n via membership, roles: owner/admin/member)
- `CompanyProfile` (the 6-step wizard data: nace[], cpv[], experienceCeiling, certifications[], personnel{}, strategy{}, automation{})
- `Tender` (İKN, title, agencyName, agencyLogoUrl, type, method, estimatedValue, deadline, cpvCodes[], rawDocsUrls[], sourceSystem)
- `Match` (tender ↔ companyProfile, fitScore 0-100, reasoning, status)
- `PipelineItem` (tender, stage enum, notes)
- `Proposal` (tender, contentJson, status, versions)
- `Document` (business, folder, name, fileUrl, validUntil, status)
- `ApiKey` (business, provider enum, encryptedKey, lastUsedAt)
- `Subscription` (Stripe: plan, seats, status)

## AI EŞLEŞTIRME MANTIĞI (core value)
Given a `CompanyProfile` and a `Tender`, compute a fit score 0-100 by checking: CPV/NACE overlap, experience ceiling vs estimated value (≥50% rule), financial criteria, personnel requirements, geography preference. Return score + human-readable Turkish reasoning + pros/risks. Use the user's connected LLM for the reasoning text; do the hard rule checks in code.

## VERİ KAYNAĞI (en kritik — bunu bana sor)
The product's lifeblood is tender data from EKAP. EKAP does not expose a simple public bulk API like SAM.gov. **Do not invent a data source.** Build the app against a clean `TenderRepository` interface with a mock/seed adapter for now (use realistic Turkish seed data — see mockups). Make swapping in a real adapter trivial later. Flag this clearly in the README.

## HUKUKİ KISIT (önemli)
Do NOT build fully-automatic e-signature submission to EKAP. E-teklif requires a qualified electronic signature (NES) and auto-signing on a user's behalf is a serious legal/security risk. The flow is: **AI prepares everything → user reviews → user signs & submits.** Keep the "otomatik e-imza" toggle present but disabled with an explanatory note.

## SECURITY
- Encrypt all stored API keys (AES-256), never log them, never expose to client.
- Multi-tenant isolation: every query scoped to the user's organization/business.
- KVKK (Turkish GDPR) compliant data handling; privacy-by-default.

## BUILD ORDER (incremental)
1. Project scaffold + theme system + shared shell (sidebar/topbar/theme toggle) matching mockups.
2. Auth (Clerk) + multi-tenant data model + seed data.
3. Static pages wired to seed data via TanStack Query (all 13 screens).
4. Apply-on-my-behalf 6-step wizard writing to CompanyProfile.
5. AI layer: integrations page (key storage) → fit-scoring → sliding AI panel → proposal generator.
6. Stripe subscriptions + plan gating.
7. Pipeline drag-and-drop + reports charts.

Start with steps 1-3 and show me the running app before moving on. Ask me whenever a product decision is ambiguous rather than guessing. Match the attached mockups precisely.
