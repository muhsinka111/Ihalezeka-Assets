# İhaleZeka — Akıllı Kamu İhale Platformu (Prototip v2)

CLEATUS (cleat.ai) iş modelinin Türk kamu ihale pazarına (EKAP / 4734 sayılı Kamu İhale Kanunu) uyarlanmış çalışan ön yüz prototipi.

## Sayfalar (pages/)
- index.html          → Prototip merkezi (tüm sayfalara link)
- landing.html        → Pazarlama / tanıtım sayfası
- dashboard.html      → Ana panel (kurum logolu öneriler)
- firsatlar.html      → İhale listesi (kurum logolu, filtreli)
- ihale-detay.html    → İhale detayı + AI analizi + uygunluk skoru
- basvur.html         → "Benim Adıma Başvur" 6 adımlı kurulum sihirbazı
- teklif.html         → AI teklif oluşturucu (sohbet + canlı belge)
- arama.html          → Gelişmiş ihale arama (doğal dil + filtreler)
- borohatti.html      → Boru hattı (Kanban)
- rakip.html          → Rakip analizi
- paraakisi.html      → Kurum harcama / para akışı analizi
- belgeler.html       → Belge merkezi (klasörler, geçerlilik takibi)
- raporlar.html       → Performans raporları + AI özet
- entegrasyonlar.html → API & entegrasyonlar (kendi anahtarını bağla)

## Ortak altyapı (pages/assets/)
- theme.css → Tüm renkler + açık/koyu tema değişkenleri
- app.js    → Sol menü (NAV dizisi), üst bar, kayan AI paneli, kurum logo üreteci

## Önemli özellikler
- **Açık/koyu tema:** Üst bardaki ay/güneş ikonu. localStorage'a kaydedilir.
- **Kayan AI paneli:** Her sayfada "AI Asistan" → CLEATUS "Ask CLEATUS" tarzı sağdan açılır panel (skorlu öneriler).
- **Kurum logoları:** izAgencyLogo() kurumun adından renkli rozet üretir. Gerçek logo URL'leri eklenince bu fonksiyon güncellenir.
- **Kendi API anahtarın:** entegrasyonlar.html — kullanıcılar OpenAI/Claude/Gemini anahtarlarını bağlar (bring-your-own-key).

## Replit
HTML/CSS/JS static site. pages/index.html'i aç. Ekstra kurulum yok.

## En kritik teknik karar
EKAP verisini hangi yetkiyle/yöntemle çekeceğin netleşmeli — ürünün can damarı bu.

## Hukuki not
"Otomatik e-imza" pasif bırakıldı: e-teklif NES (nitelikli elektronik imza) gerektirir. Model: AI hazırlar, kullanıcı imzalar.
