/* ============================================================
   İhaleZeka — Ortak Uygulama Mantığı (app.js)
   Sol menü + üst bar + kayan AI paneli her sayfaya buradan enjekte edilir.
   Tek yerden düzenle, tüm sayfalar güncellensin.
   ============================================================ */

const NAV = [
  { label:'Ana Sayfa',          icon:'home-2',          href:'dashboard.html',  key:'dashboard' },
  { label:'Fırsatlarım',        icon:'target-arrow',    href:'firsatlar.html',  key:'firsatlar', badge:'14' },
  { label:'Benim Adıma Başvur', icon:'rocket',          href:'basvur.html',     key:'basvur' },
  { label:'İhale Arama',        icon:'search',          href:'arama.html',      key:'arama' },
  { label:'Tekliflerim',        icon:'file-text',       href:'teklif.html',     key:'teklif' },
  { label:'Boru Hattı',         icon:'layout-kanban',   href:'borohatti.html',  key:'borohatti' },
  { label:'Rakip Analizi',      icon:'users-group',     href:'rakip.html',      key:'rakip' },
  { label:'Para Akışı',         icon:'cash',            href:'paraakisi.html',  key:'paraakisi', tagNew:true },
  { label:'Belgelerim',         icon:'folder',          href:'belgeler.html',   key:'belgeler' },
  { label:'Raporlar',           icon:'chart-histogram', href:'raporlar.html',   key:'raporlar' },
];
const NAV_SETUP = [
  { label:'Entegrasyonlar',     icon:'plug',            href:'entegrasyonlar.html', key:'entegrasyonlar' },
  { label:'Ayarlar',            icon:'settings',        href:'#',                   key:'ayarlar' },
];

/* Kurum logo rozeti — gerçek logo yoksa kurumun baş harfleriyle renkli rozet üretir.
   Kullanım: izAgencyLogo('Karayolları Genel Müdürlüğü')  */
const AGENCY_COLORS = ['#2C46D8','#149E6A','#D98A0B','#8B5CF6','#0EA5E9','#E11D48','#0D9488','#DB2777'];
function izAgencyLogo(name, size=34){
  const clean = (name||'?').replace(/^(T\.C\.|TC)\s*/i,'').trim();
  const words = clean.split(/\s+/).filter(Boolean);
  const initials = (words[0][0] + (words[1]? words[1][0] : '')).toUpperCase();
  let h=0; for(let i=0;i<clean.length;i++) h=clean.charCodeAt(i)+((h<<5)-h);
  const c = AGENCY_COLORS[Math.abs(h)%AGENCY_COLORS.length];
  return `<span class="agency-logo" title="${clean}" style="width:${size}px;height:${size}px;background:${c}1a;color:${c};font-size:${size*0.36}px">${initials}</span>`;
}

function buildSidebar(activeKey){
  const links = NAV.map(n=>{
    const extra = n.badge ? `<span class="badge">${n.badge}</span>` : (n.tagNew ? `<span class="tag-new">Yeni</span>` : '');
    return `<a href="${n.href}" class="${n.key===activeKey?'active':''}"><i class="ti ti-${n.icon}"></i> ${n.label} ${extra}</a>`;
  }).join('');
  const setup = NAV_SETUP.map(n=>
    `<a href="${n.href}" class="${n.key===activeKey?'active':''}"><i class="ti ti-${n.icon}"></i> ${n.label}</a>`
  ).join('');
  return `
  <aside class="sidebar">
    <div class="logo">
      <div class="logo-badge"><i class="ti ti-gavel"></i></div>
      <div class="logo-text"><b>İhaleZeka</b><span>Akıllı Kamu İhale</span></div>
    </div>
    <nav class="nav">
      ${links}
      <div class="nav-label">Kurulum</div>
      ${setup}
    </nav>
    <div class="userbox">
      <div class="avatar">MY</div>
      <div style="flex:1;min-width:0">
        <div style="font-size:12.5px;font-weight:600">Mehmet Yılmaz</div>
        <div style="font-size:10.5px;color:var(--text-3)">Elementa Yapı · Pro Plan</div>
      </div>
    </div>
  </aside>`;
}

function buildTopbar(){
  return `
  <div class="topbar">
    <div class="searchbar">
      <i class="ti ti-search"></i>
      <input placeholder="İhale, kurum, anahtar kelime, CPV kodu ara..." />
    </div>
    <div class="spacer"></div>
    <button class="btn-ai" onclick="izToggleAI()"><i class="ti ti-sparkles"></i> AI Asistan</button>
    <div class="icon-btn theme-toggle" onclick="toggleTheme()" title="Tema değiştir"><i class="ti ti-moon" id="themeIcon"></i></div>
    <div class="icon-btn" title="Bildirimler"><i class="ti ti-bell"></i><span class="dot">7</span></div>
    <div class="avatar">MY</div>
  </div>`;
}

/* Kayan AI asistan paneli (CLEATUS "Ask CLEATUS" tarzı, sağdan açılır) */
function buildAIPanel(){
  return `
  <div class="ai-overlay" id="aiOverlay" onclick="izToggleAI()"></div>
  <aside class="ai-panel" id="aiPanel">
    <div class="ai-panel-head">
      <div style="display:flex;align-items:center;gap:8px">
        <div class="logo-badge" style="width:26px;height:26px;font-size:15px"><i class="ti ti-sparkles"></i></div>
        <b style="font-size:14px">İhaleZeka'ya Sor</b>
        <span class="badge-pill pill-brand" style="font-size:9px">BETA</span>
      </div>
      <div style="display:flex;gap:6px">
        <div class="icon-btn" style="width:30px;height:30px;font-size:15px" title="Yeni sohbet"><i class="ti ti-plus"></i></div>
        <div class="icon-btn" style="width:30px;height:30px;font-size:15px" title="Geçmiş"><i class="ti ti-history"></i></div>
        <div class="icon-btn" style="width:30px;height:30px;font-size:15px" onclick="izToggleAI()" title="Kapat"><i class="ti ti-x"></i></div>
      </div>
    </div>
    <div class="ai-panel-body">
      <div class="ai-user-msg">Bugünkü en iyi önerilerimi göster.</div>
      <div class="tiny" style="margin:4px 0 10px"><i class="ti ti-circle-check" style="color:var(--green)"></i> Öneriler yüklendi</div>
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
        <div class="logo-badge" style="width:24px;height:24px;font-size:13px"><i class="ti ti-gavel"></i></div>
        <div><b style="font-size:13px">Fırsatlar</b><div class="tiny">425 ihaleden 3 tanesi gösteriliyor</div></div>
      </div>

      <div class="ai-rec">
        <div class="ai-rec-top"><span class="tiny">CPV: 45214200</span><span class="badge-pill pill-green" style="font-size:9px">PİPELINE'DA</span><span class="ai-score">98<span class="tiny">/100</span></span></div>
        <b style="font-size:13px;display:block;margin:5px 0">Okul binası yapım işi — 24 derslik</b>
        <div style="display:flex;align-items:center;gap:7px;margin-bottom:8px">${izAgencyLogo('İstanbul İl Milli Eğitim Müdürlüğü',22)}<span class="tiny">İstanbul İl MEM · Son: 20 May · 9 gün</span></div>
        <div style="display:flex;gap:6px"><button class="btn primary sm" style="flex:1;justify-content:center">Pipeline'ı gör</button><button class="btn sm">Aç</button></div>
      </div>

      <div class="ai-rec">
        <div class="ai-rec-top"><span class="tiny">CPV: 33100000</span><span class="badge-pill pill-brand" style="font-size:9px">YENİ</span><span class="ai-score">97<span class="tiny">/100</span></span></div>
        <b style="font-size:13px;display:block;margin:5px 0">Tıbbi cihaz alımı</b>
        <div style="display:flex;align-items:center;gap:7px;margin-bottom:8px">${izAgencyLogo('Ankara Şehir Hastanesi',22)}<span class="tiny">Ankara Şehir Hastanesi · 14 gün</span></div>
        <div style="display:flex;gap:6px"><button class="btn primary sm" style="flex:1;justify-content:center">Pipeline'a ekle</button><button class="btn sm">Çıkar</button></div>
      </div>

      <div class="ai-rec">
        <div class="ai-rec-top"><span class="tiny">CPV: 45233140</span><span class="badge-pill pill-amber" style="font-size:9px">İZLENİYOR</span><span class="ai-score">85<span class="tiny">/100</span></span></div>
        <b style="font-size:13px;display:block;margin:5px 0">Yol yapım ve onarım işi</b>
        <div style="display:flex;align-items:center;gap:7px;margin-bottom:8px">${izAgencyLogo('Karayolları Genel Müdürlüğü',22)}<span class="tiny">Karayolları 1. Bölge Md. · 17 gün</span></div>
        <div style="display:flex;gap:6px"><button class="btn primary sm" style="flex:1;justify-content:center">Pipeline'a ekle</button><button class="btn sm">Aç</button></div>
      </div>

      <div class="tiny" style="text-align:center;margin-top:6px">Daha fazla sonuç var — devam etmek için sorun.</div>
    </div>
    <div class="ai-panel-input">
      <input placeholder="Bir şey sorun, ya da @ ile bağlam ekle" />
      <button class="btn primary sm" aria-label="Gönder"><i class="ti ti-arrow-up"></i></button>
    </div>
  </aside>`;
}
function izToggleAI(){
  document.getElementById('aiPanel')?.classList.toggle('open');
  document.getElementById('aiOverlay')?.classList.toggle('show');
}

/* Theme handling with persistence */
function applyTheme(t){
  document.documentElement.setAttribute('data-theme', t);
  const ic = document.getElementById('themeIcon');
  if(ic) ic.className = t==='dark' ? 'ti ti-sun' : 'ti ti-moon';
  try{ localStorage.setItem('iz-theme', t); }catch(e){}
}
function toggleTheme(){
  const cur = document.documentElement.getAttribute('data-theme')||'light';
  applyTheme(cur==='dark'?'light':'dark');
}
(function initTheme(){
  let t='light';
  try{ t = localStorage.getItem('iz-theme') || 'light'; }catch(e){}
  document.documentElement.setAttribute('data-theme', t);
})();

/* Mount shell: IZ.mount('dashboard') her sayfanın altında çağrılır */
const IZ = {
  agencyLogo: izAgencyLogo,
  mount(activeKey){
    const root = document.getElementById('app');
    if(!root) return;
    const main = root.querySelector('.main');
    root.insertAdjacentHTML('afterbegin', buildSidebar(activeKey));
    if(main) main.insertAdjacentHTML('afterbegin', buildTopbar());
    document.body.insertAdjacentHTML('beforeend', buildAIPanel());
    document.querySelectorAll('.js-logo').forEach(el=>{
      el.outerHTML = izAgencyLogo(el.getAttribute('data-agency'), parseInt(el.getAttribute('data-size'))||34);
    });
    const t = document.documentElement.getAttribute('data-theme')||'light';
    const ic = document.getElementById('themeIcon');
    if(ic) ic.className = t==='dark' ? 'ti ti-sun' : 'ti ti-moon';
  }
};
